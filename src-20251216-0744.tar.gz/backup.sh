tar --exclude='*/.venv' --exclude='*.tar.gz' \
    -czf "$(basename "$PWD")-$(date +%Y%m%d-%H%M).tar.gz" .
