def main():
    print("Hello from src!")


if __name__ == "__main__":
    main()
